
plugins {
    java
    `maven-publish`
}

group = "com.abubakar.customweapons"
version = "1.0.0"

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.20.1-R0.1-SNAPSHOT")
}

tasks.withType<JavaCompile>() {
    options.encoding = "UTF-8"
}

tasks.register<Jar>("shadowJar") {
    archiveBaseName.set("customweapons")
    from(sourceSets.main.get().output)
    // No relocations needed as we use only Paper API
}

publishing {
    publications {
        create<MavenPublication>("mavenJava") {
            from(components["java"])
        }
    }
}
