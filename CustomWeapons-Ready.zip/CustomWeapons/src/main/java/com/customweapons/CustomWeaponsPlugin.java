package com.customweapons;

import org.bukkit.plugin.java.JavaPlugin;

public class CustomWeaponsPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("CustomWeapons Plugin Enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("CustomWeapons Plugin Disabled!");
    }
}
