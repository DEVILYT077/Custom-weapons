
package com.abubakar.customweapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.List;

public class WeaponItems {
    public static ItemStack fireSword() {
        return build(Material.DIAMOND_SWORD, 10001, ChatColor.RED + "Fire Sword", Arrays.asList(ChatColor.GRAY + "Right-click: shoot fireball"));
    }

    public static ItemStack iceSword() {
        return build(Material.IRON_SWORD, 10002, ChatColor.AQUA + "Ice Sword", Arrays.asList(ChatColor.GRAY + "Right-click: ice spike (freeze 5s, 0.5❤)"));
    }

    public static ItemStack shadowScythe() {
        return build(Material.NETHERITE_HOE, 10003, ChatColor.DARK_RED + "Shadow Scythe", Arrays.asList(ChatColor.GRAY + "Right-click: red wave (3❤)"));
    }

    public static ItemStack lightningHammer() {
        return build(Material.GOLDEN_AXE, 10004, ChatColor.GOLD + "Lightning Hammer", Arrays.asList(ChatColor.GRAY + "Right-click: thunder strike (4❤)"));
    }

    private static ItemStack build(Material mat, int customModelData, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.setCustomModelData(customModelData);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String id;
        switch (customModelData) {
            case 10001 -> id = CWConstants.WEAPON_FIRE_SWORD;
            case 10002 -> id = CWConstants.WEAPON_ICE_SWORD;
            case 10003 -> id = CWConstants.WEAPON_SHADOW_SCYTHE;
            default -> id = CWConstants.WEAPON_LIGHTNING_HAMMER;
        }
        pdc.set(CWConstants.PDC_WEAPON_ID, PersistentDataType.STRING, id);
        it.setItemMeta(meta);
        return it;
    }
}
