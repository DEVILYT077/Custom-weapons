
package com.abubakar.customweapons;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Cooldowns {
    private final Map<String, Map<UUID, Long>> map = new HashMap<>();
    private final long cooldownMillis;

    public Cooldowns(long cooldownSeconds) {
        this.cooldownMillis = cooldownSeconds * 1000L;
    }

    public boolean ready(String ability, UUID player) {
        long now = System.currentTimeMillis();
        Map<UUID, Long> m = map.computeIfAbsent(ability, k -> new HashMap<>());
        Long last = m.getOrDefault(player, 0L);
        if (now - last >= cooldownMillis) {
            m.put(player, now);
            return true;
        }
        return false;
    }

    public long remaining(String ability, UUID player) {
        long now = System.currentTimeMillis();
        Map<UUID, Long> m = map.computeIfAbsent(ability, k -> new HashMap<>());
        Long last = m.getOrDefault(player, 0L);
        long rem = cooldownMillis - (now - last);
        return Math.max(0L, rem);
    }
}
