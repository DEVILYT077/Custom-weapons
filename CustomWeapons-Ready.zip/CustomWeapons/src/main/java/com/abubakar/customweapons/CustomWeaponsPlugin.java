
package com.abubakar.customweapons;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.SoundCategory;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CustomWeaponsPlugin extends JavaPlugin implements Listener {
    private Cooldowns cooldowns;
    private File dataFile;
    private FileConfiguration craftedFlags;

    private NamespacedKey KEY_RECIPE_FIRE;
    private NamespacedKey KEY_RECIPE_ICE;
    private NamespacedKey KEY_RECIPE_SHADOW;
    private NamespacedKey KEY_RECIPE_LIGHTNING;

    private boolean lightningVisualOnly;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadLocal();
        Bukkit.getPluginManager().registerEvents(this, this);
        registerRecipes();
        this.getCommand("customweapons").setExecutor((sender, cmd, label, args) -> {
            if (!sender.hasPermission("customweapons.admin")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length >= 3 && args[0].equalsIgnoreCase("give")) {
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
                String w = args[2].toLowerCase(Locale.ROOT);
                ItemStack it = null;
                switch (w) {
                    case "fire", "fire_sword" -> it = WeaponItems.fireSword();
                    case "ice", "ice_sword" -> it = WeaponItems.iceSword();
                    case "shadow", "shadow_scythe" -> it = WeaponItems.shadowScythe();
                    case "lightning", "lightning_hammer" -> it = WeaponItems.lightningHammer();
                }
                if (it == null) { sender.sendMessage(ChatColor.RED + "Unknown weapon."); return true; }
                target.getInventory().addItem(it);
                sender.sendMessage(ChatColor.GREEN + "Gave " + target.getName() + " " + it.getItemMeta().getDisplayName());
                return true;
            }
            sender.sendMessage(ChatColor.YELLOW + "Usage: /customweapons give <player> <fire|ice|shadow|lightning>");
            return true;
        });
    }

    private void reloadLocal() {
        int cd = getConfig().getInt("cooldown-seconds", 10);
        cooldowns = new Cooldowns(cd);
        lightningVisualOnly = getConfig().getBoolean("lightning-visual-only", true);

        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try { getDataFolder().mkdirs(); dataFile.createNewFile(); } catch (IOException ignored) { }
        }
        craftedFlags = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveFlags() {
        try { craftedFlags.save(dataFile); } catch (IOException ignored) { }
    }

    private boolean recipeUsed(String id) { return craftedFlags.getBoolean("crafted." + id, false); }
    private void setRecipeUsed(String id) { craftedFlags.set("crafted." + id, true); saveFlags(); }

    private void registerRecipes() {
        KEY_RECIPE_FIRE = new NamespacedKey(CWConstants.NAMESPACE, "fire_sword");
        KEY_RECIPE_ICE = new NamespacedKey(CWConstants.NAMESPACE, "ice_sword");
        KEY_RECIPE_SHADOW = new NamespacedKey(CWConstants.NAMESPACE, "shadow_scythe");
        KEY_RECIPE_LIGHTNING = new NamespacedKey(CWConstants.NAMESPACE, "lightning_hammer");

        // Fire Sword: D B D / B N B / D B D (D=Blaze Powder, B=Blaze Rod, N=Diamond Sword base)
        ShapedRecipe fire = new ShapedRecipe(KEY_RECIPE_FIRE, WeaponItems.fireSword());
        fire.shape("DBD","B N","DBD");
        fire.setIngredient('D', Material.BLAZE_POWDER);
        fire.setIngredient('B', Material.BLAZE_ROD);
        fire.setIngredient('N', new RecipeChoice.ExactChoice(new ItemStack(Material.DIAMOND_SWORD)));

        // Ice Sword: S P S / P N P / S P S (S=Snow Block, P=Packed Ice, N=Iron Sword)
        ShapedRecipe ice = new ShapedRecipe(KEY_RECIPE_ICE, WeaponItems.iceSword());
        ice.shape("SPS","PNP","SPS");
        ice.setIngredient('S', Material.SNOW_BLOCK);
        ice.setIngredient('P', Material.PACKED_ICE);
        ice.setIngredient('N', new RecipeChoice.ExactChoice(new ItemStack(Material.IRON_SWORD)));

        // Shadow Scythe: N E N / E H E / N E N (N=Nether Wart Block, E=Ender Pearl, H=Netherite Hoe)
        ShapedRecipe shadow = new ShapedRecipe(KEY_RECIPE_SHADOW, WeaponItems.shadowScythe());
        shadow.shape("NEN","EHE","NEN");
        shadow.setIngredient('N', Material.NETHER_WART_BLOCK);
        shadow.setIngredient('E', Material.ENDER_PEARL);
        shadow.setIngredient('H', new RecipeChoice.ExactChoice(new ItemStack(Material.NETHERITE_HOE)));

        // Lightning Hammer: G R G / R H R / G R G (G=Gold Block, R=Redstone Block, H=Golden Axe)
        ShapedRecipe hammer = new ShapedRecipe(KEY_RECIPE_LIGHTNING, WeaponItems.lightningHammer());
        hammer.shape("GRG","RHR","GRG");
        hammer.setIngredient('G', Material.GOLD_BLOCK);
        hammer.setIngredient('R', Material.REDSTONE_BLOCK);
        hammer.setIngredient('H', new RecipeChoice.ExactChoice(new ItemStack(Material.GOLDEN_AXE)));

        Bukkit.addRecipe(fire);
        Bukkit.addRecipe(ice);
        Bukkit.addRecipe(shadow);
        Bukkit.addRecipe(hammer);
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        ItemStack result = e.getInventory().getResult();
        if (result == null) return;
        if (!result.hasItemMeta()) return;
        var meta = result.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        String id = pdc.get(CWConstants.PDC_WEAPON_ID, PersistentDataType.STRING);
        if (id == null) return;

        if (recipeUsed(id)) {
            e.getInventory().setResult(new ItemStack(Material.AIR));
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        if (e.getEntity() instanceof Snowball snow) {
            if (snow.getScoreboardTags().contains("CW_ICE")) {
                if (e.getHitEntity() instanceof LivingEntity le) {
                    le.setFreezeTicks(100);
                    le.damage(1.0, (Entity) snow.getShooter()); // 0.5 heart
                    le.getWorld().playSound(le.getLocation(), CWConstants.SOUND_ICE, SoundCategory.PLAYERS, 1f, 1f);
                }
            } else if (snow.getScoreboardTags().contains("CW_SHADOW")) {
                if (e.getHitEntity() instanceof LivingEntity le) {
                    le.damage(6.0, (Entity) snow.getShooter()); // 3 hearts
                    le.getWorld().playSound(le.getLocation(), CWConstants.SOUND_SHADOW, SoundCategory.PLAYERS, 1f, 1f);
                }
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getItem() == null) return;
        ItemStack it = e.getItem();
        if (!it.hasItemMeta()) return;
        var meta = it.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        String id = pdc.get(CWConstants.PDC_WEAPON_ID, PersistentDataType.STRING);
        if (id == null) return;

        Player p = e.getPlayer();
        String ability = id + "_ability";
        if (!cooldowns.ready(ability, p.getUniqueId())) {
            long ms = cooldowns.remaining(ability, p.getUniqueId());
            p.sendMessage(ChatColor.RED + "Ability on cooldown: " + (ms/1000.0) + "s left");
            return;
        }

        switch (id) {
            case CWConstants.WEAPON_FIRE_SWORD -> fireAbility(p);
            case CWConstants.WEAPON_ICE_SWORD -> iceAbility(p);
            case CWConstants.WEAPON_SHADOW_SCYTHE -> shadowAbility(p);
            case CWConstants.WEAPON_LIGHTNING_HAMMER -> lightningAbility(p);
        }
    }

    private void fireAbility(Player p) {
        SmallFireball fb = p.launchProjectile(SmallFireball.class);
        fb.setIsIncendiary(true);
        fb.setYield(0F);
        p.playSound(p.getLocation(), CWConstants.SOUND_FIRE, SoundCategory.PLAYERS, 1f, 1f);
        markCrafted(CWConstants.WEAPON_FIRE_SWORD);
    }

    private void iceAbility(Player p) {
        Snowball s = p.launchProjectile(Snowball.class);
        s.addScoreboardTag("CW_ICE");
        s.setItem(WeaponItems.iceSword()); // cosmetic trail
        p.playSound(p.getLocation(), CWConstants.SOUND_ICE, SoundCategory.PLAYERS, 1f, 1f);
        markCrafted(CWConstants.WEAPON_ICE_SWORD);
    }

    private void shadowAbility(Player p) {
        Snowball s = p.launchProjectile(Snowball.class);
        s.addScoreboardTag("CW_SHADOW");
        // give it higher speed and red particle trail
        Vector v = p.getLocation().getDirection().normalize().multiply(1.5);
        s.setVelocity(v);
        p.spawnParticle(org.bukkit.Particle.REDSTONE, p.getEyeLocation().add(v), 30, new org.bukkit.Particle.DustOptions(org.bukkit.Color.fromRGB(255,0,0), 1.5F));
        p.playSound(p.getLocation(), CWConstants.SOUND_SHADOW, SoundCategory.PLAYERS, 1f, 1f);
        markCrafted(CWConstants.WEAPON_SHADOW_SCYTHE);
    }

    private void lightningAbility(Player p) {
        var target = p.getTargetBlockExact(30);
        if (target == null) { p.sendMessage(ChatColor.YELLOW + "No target in sight."); return; }
        if (lightningVisualOnly) {
            p.getWorld().strikeLightningEffect(target.getLocation());
        } else {
            p.getWorld().strikeLightning(target.getLocation());
        }
        // damage nearest living entity near target
        double minDist = Double.MAX_VALUE; LivingEntity best = null;
        for (Entity e : p.getWorld().getNearbyEntities(target.getLocation(), 3,3,3)) {
            if (e instanceof LivingEntity le && !le.equals(p)) {
                double d = e.getLocation().distanceSquared(target.getLocation());
                if (d < minDist) { minDist = d; best = le; }
            }
        }
        if (best != null) best.damage(8.0, p); // 4 hearts
        p.playSound(p.getLocation(), CWConstants.SOUND_LIGHTNING, SoundCategory.PLAYERS, 1f, 1f);
        markCrafted(CWConstants.WEAPON_LIGHTNING_HAMMER);
    }

    private void markCrafted(String id) {
        // Safety: ensure once any item is actually used (crafted earlier), mark crafted flag.
        if (!recipeUsed(id)) {
            craftedFlags.set("crafted." + id, true);
            saveFlags();
        }
    }
}
