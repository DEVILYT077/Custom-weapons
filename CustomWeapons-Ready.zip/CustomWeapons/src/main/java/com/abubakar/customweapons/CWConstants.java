
package com.abubakar.customweapons;

import org.bukkit.NamespacedKey;

public final class CWConstants {
    public static final String NAMESPACE = "customweapons";
    public static final String KEY_WEAPON_ID = "weapon_id";
    public static final NamespacedKey PDC_WEAPON_ID = new NamespacedKey(NAMESPACE, KEY_WEAPON_ID);

    public static final String WEAPON_FIRE_SWORD = "fire_sword";
    public static final String WEAPON_ICE_SWORD = "ice_sword";
    public static final String WEAPON_SHADOW_SCYTHE = "shadow_scythe";
    public static final String WEAPON_LIGHTNING_HAMMER = "lightning_hammer";

    public static final String SOUND_FIRE = NAMESPACE + ":fire_cast";
    public static final String SOUND_ICE = NAMESPACE + ":ice_cast";
    public static final String SOUND_SHADOW = NAMESPACE + ":shadow_cast";
    public static final String SOUND_LIGHTNING = NAMESPACE + ":lightning_cast";
}
